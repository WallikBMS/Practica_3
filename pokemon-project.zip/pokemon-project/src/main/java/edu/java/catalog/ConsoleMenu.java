package edu.java.catalog;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Цикл меню. Действия, ввод предметных данных и проверку выхода подключает студент. */
public final class ConsoleMenu {
    private final Scanner input;
    private final PrintStream output;
    private final List<MenuAction> actions;

    public ConsoleMenu(Scanner input, PrintStream output, Variant variant) {
        this.input = input;
        this.output = output;
        actions = Arrays.stream(MenuAction.values())
                .filter(action -> variant == Variant.DND || action != MenuAction.CHANGE_QUANTITY)
                .toList();
    }

    public void run(Consumer<MenuAction> handler, BooleanSupplier mayExit) {
        while (true) {
            for (int i = 0; i < actions.size(); i++) {
                output.printf("%d. %s%n", i + 1, actions.get(i).title());
            }
            output.println("0. Выход");
            output.print("Номер действия: ");
            if (!input.hasNextLine()) {
                // TODO: при завершении потока согласуйте поведение несохранённых изменений.
                output.println("Ввод завершён.");
                return;
            }
            int choice;
            try {
                choice = Integer.parseInt(input.nextLine().strip());
            } catch (NumberFormatException exception) {
                output.println("Введите целый номер действия.");
                continue;
            }
            if (choice == 0) {
                if (mayExit.getAsBoolean()) {
                    return;
                }
            } else if (choice >= 1 && choice <= actions.size()) {
                handler.accept(actions.get(choice - 1));
            } else {
                output.println("Такого пункта нет.");
            }
        }
    }
}
