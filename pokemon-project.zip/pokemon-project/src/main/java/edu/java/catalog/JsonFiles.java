package edu.java.catalog;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
public final class JsonFiles {
    private JsonFiles() {}
    public static String read(Path path) throws IOException {
        if (!Files.exists(path)) throw new NoSuchFileException(path.toString());
        if (Files.size(path) > 5L * 1024 * 1024) throw new IOException("JSON больше 5 МБ");
        return Files.readString(path, StandardCharsets.UTF_8);
    }
    public static void write(Path path, Object value, ObjectMapper mapper) throws IOException {
        String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        Path target = path.toAbsolutePath().normalize();
        Files.createDirectories(target.getParent());
        Path tmp = Files.createTempFile(target.getParent(), "pokemon-", ".tmp");
        try {
            Files.writeString(tmp, json, StandardCharsets.UTF_8);
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(tmp); }
    }
}