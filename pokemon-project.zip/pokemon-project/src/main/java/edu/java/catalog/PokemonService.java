package edu.java.catalog;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
public final class PokemonService {
    private final HttpSupport infrastructure;
    private final ObjectMapper mapper;
    private final Path data;
    private final PokemonCatalog catalog = new PokemonCatalog();
    public PokemonService(HttpSupport infrastructure, Path data) { this.infrastructure=infrastructure; this.mapper=infrastructure.json(); this.data=data; }
    public PokemonCatalog catalog() { return catalog; }
    public Path statePath() { return data.resolve("state.json"); }
    public void restore() throws IOException { if (Files.exists(statePath())) catalog.restore(mapper.readValue(JsonFiles.read(statePath()),CatalogSnapshot.class)); }
    public void save() throws IOException { JsonFiles.write(statePath(),catalog.snapshot(),mapper); catalog.clean(); }
    public void importSnapshots(List<Path> paths) throws IOException {
        List<PokemonCard> batch = new ArrayList<>();
        for (Path path : paths) batch.add(parse(JsonFiles.read(path)));
        catalog.importCards(batch);
    }
    public PokemonCard parse(String json) throws IOException {
        if (json == null || json.isBlank()) throw new IOException("Пустой JSON");
        var root = mapper.readTree(json);
        if (!root.isObject()) throw new IOException("Корень JSON должен быть объектом");
        return PokemonMapper.convert(mapper.treeToValue(root,PokemonResponse.class));
    }
    public void loadCache(List<Integer> ids) throws IOException {
        List<Path> files = new ArrayList<>();
        for (int id : ids) { checkId(id); files.add(data.resolve("cache").resolve("pokemon-"+id+".json")); }
        importSnapshots(files);
    }
    private static void checkId(int id) { if (id<=0) throw new IllegalArgumentException("ID должен быть положительным"); }
    public void online(List<Integer> ids) throws IOException, InterruptedException {
        if (ids.isEmpty() || ids.size()>20) throw new IllegalArgumentException("За раз от 1 до 20 ID");
        List<PokemonCard> cards = new ArrayList<>();
        Map<Integer,String> raw = new LinkedHashMap<>();
        for (int id : ids) checkId(id);
        for (int id : ids) {
            if (!raw.isEmpty()) Thread.sleep(1000);
            var response = infrastructure.http().get("https://pokeapi.co/api/v2/pokemon/{id}").routeParam("id",String.valueOf(id)).asString();
            if (response.getStatus()!=200) throw new IOException("HTTP " + response.getStatus()+" для ID " + id);
            String json=response.getBody();
            PokemonCard card=parse(json);
            if (card.id()!=id) throw new IOException("ID ответа не совпадает с запросом");
            cards.add(card); raw.put(id,json);
        }
        catalog.importCards(cards);
        for (var entry:raw.entrySet()) JsonFiles.write(data.resolve("cache/pokemon-"+entry.getKey()+".json"),mapper.readTree(entry.getValue()),mapper);
    }
    public void exportTeam(String title,String file) throws IOException { JsonFiles.write(exportPath(file),catalog.exportTeam(title),mapper); }
    public int importTeam(String file) throws IOException { return catalog.importTeam(mapper.readValue(JsonFiles.read(exportPath(file)),TeamExport.class)); }
    private Path exportPath(String name) {
        if (name==null || !name.matches("[a-zA-Z0-9_-]{1,60}\\.json")) throw new IllegalArgumentException("Имя: латиница/цифры/_/- и .json");
        Path dir=data.resolve("exports").toAbsolutePath().normalize(); Path path=dir.resolve(name).normalize();
        if (!path.startsWith(dir)) throw new IllegalArgumentException("Недопустимый путь");
        return path;
    }
}