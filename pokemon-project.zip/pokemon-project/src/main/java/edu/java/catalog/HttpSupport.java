package edu.java.catalog;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import kong.unirest.core.Unirest;
import kong.unirest.core.UnirestInstance;
import kong.unirest.modules.jackson.JacksonObjectMapper;

/** Конфигурация инфраструктуры; запросы и предметную модель пишет студент. */
public final class HttpSupport implements AutoCloseable {
    private final ObjectMapper json;
    private final UnirestInstance http;

    public HttpSupport() {
        json = new ObjectMapper()
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        http = Unirest.spawnInstance();
        http.config()
                .connectTimeout(5_000)
                .requestTimeout(15_000)
                .setDefaultHeader("Accept", "application/json")
                .setObjectMapper(new JacksonObjectMapper(json));
    }

    public ObjectMapper json() {
        return json;
    }

    public UnirestInstance http() {
        return http;
    }

    @Override
    public void close() {
        http.close();
    }
}
