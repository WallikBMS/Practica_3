package edu.java.catalog;

import java.util.Locale;

public enum Variant {
    DND("Бестиарий D&D"),
    POKEMON("Покедекс и команды"),
    BOOKS("Список чтения"),
    ART("Тематическая выставка");

    private final String title;

    Variant(String title) {
        this.title = title;
    }

    public String title() {
        return title;
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public static Variant parse(String input) {
        return valueOf(input.strip().toUpperCase(Locale.ROOT));
    }
}
