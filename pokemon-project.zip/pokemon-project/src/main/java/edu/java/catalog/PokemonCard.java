package edu.java.catalog;

import java.util.*;
public record PokemonCard(int id, String name, List<String> types, BaseStats stats) {
    public PokemonCard {
        if (id <= 0 || name == null || name.isBlank() || stats == null || types == null || types.isEmpty())
            throw new IllegalArgumentException("Неверная карточка Pokémon");
        name = name.strip();
        types = List.copyOf(types);
        if (types.stream().anyMatch(t -> t == null || t.isBlank()) || new HashSet<>(types).size() != types.size())
            throw new IllegalArgumentException("Неверные типы Pokémon");
    }
}