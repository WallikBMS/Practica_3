package edu.java.catalog;

import java.util.*;
public final class PokemonMapper {
    private PokemonMapper() {}
    public static PokemonCard convert(PokemonResponse r) {
        if (r == null || r.id() == null || r.name() == null || r.types() == null || r.stats() == null)
            throw new IllegalArgumentException("Нет обязательных полей Pokémon");
        List<String> types = new ArrayList<>();
        for (var t : r.types()) {
            if (t == null || t.type() == null || t.type().name() == null) throw new IllegalArgumentException("Нет типа");
            types.add(t.type().name());
        }
        Set<String> required = Set.of("hp", "attack", "defense", "special-attack", "special-defense", "speed");
        Map<String,Integer> values = new HashMap<>();
        for (var s : r.stats()) {
            if (s == null || s.stat() == null || s.stat().name() == null) throw new IllegalArgumentException("Нет имени характеристики");
            String key = s.stat().name();
            if (required.contains(key)) {
                if (s.baseStat() == null || s.baseStat() <= 0 || values.putIfAbsent(key, s.baseStat()) != null)
                    throw new IllegalArgumentException("Повтор или неверное значение: " + key);
            }
        }
        if (!values.keySet().equals(required)) throw new IllegalArgumentException("Не хватает обязательных характеристик");
        return new PokemonCard(r.id(), r.name(), types, new BaseStats(values.get("hp"), values.get("attack"),
            values.get("defense"), values.get("special-attack"), values.get("special-defense"), values.get("speed")));
    }
}