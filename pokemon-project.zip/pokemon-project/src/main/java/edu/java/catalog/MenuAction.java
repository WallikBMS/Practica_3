package edu.java.catalog;

public enum MenuAction {
    LOAD_ONLINE("Загрузить из API"),
    IMPORT_SNAPSHOT("Импортировать исходный JSON-снимок"),
    LOAD_CACHE("Прочитать кэш без сети"),
    SHOW_CATALOG("Показать каталог"),
    SEARCH("Найти записи"),
    FILTER("Отфильтровать каталог"),
    CREATE_COLLECTION("Создать подборку"),
    SHOW_COLLECTION("Показать подборку"),
    ADD_ENTRY("Добавить элемент"),
    REMOVE_ENTRY("Удалить элемент"),
    CHANGE_QUANTITY("Изменить количество (D&D)"),
    SUMMARY("Показать сводку"),
    SAVE("Сохранить рабочее состояние"),
    EXPORT("Экспортировать подборку"),
    IMPORT_EXPORT("Импортировать подборку");

    private final String title;

    MenuAction(String title) {
        this.title = title;
    }

    public String title() {
        return title;
    }
}
