package edu.java.catalog;

import java.util.List;
public record TeamExport(int schemaVersion, String variant, String title, List<Item> items) {
    public record Item(PokemonCard card) {}
}