package edu.java.catalog;

import java.util.*;
public record PokemonTeam(String title, List<Integer> items) {
    public PokemonTeam {
        if (title == null || title.isBlank() || title.strip().length() > 80 || items == null || items.size() > 6)
            throw new IllegalArgumentException("Неверная команда");
        title = title.strip(); items = List.copyOf(items);
        if (items.stream().anyMatch(id -> id == null || id <= 0) || new HashSet<>(items).size() != items.size())
            throw new IllegalArgumentException("Повторный или неверный ID");
    }
}