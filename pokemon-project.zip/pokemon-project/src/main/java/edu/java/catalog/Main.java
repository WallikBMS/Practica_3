package edu.java.catalog;

import java.nio.file.*;
import java.util.*;
public final class Main {
    private Main() {}
    public static void main(String[] args) {
        if (args.length<1 || args.length>2 || !"pokemon".equalsIgnoreCase(args[0])) {
            System.out.println("Запуск: .\\mvnw.cmd exec:java '-Dexec.args=pokemon'"); return;
        }
        Path dir=Path.of(args.length==2?args[1]:"data").toAbsolutePath().normalize();
        try (HttpSupport http=new HttpSupport(); Scanner scanner=new Scanner(System.in)) {
            PokemonService service=new PokemonService(http,dir);
            System.out.println("Покедекс и команды Pokémon");
            System.out.println("Рабочий файл: "+service.statePath());
            try { service.restore(); } catch(Exception ex) { System.err.println("Повреждённое состояние, запуск остановлен: "+ex.getMessage()); return; }
            new ConsoleMenu(scanner,System.out,Variant.POKEMON).run(action -> {
                try { execute(action,service,scanner); }
                catch(Exception ex) { System.out.println("Отказ: "+ex.getMessage()); }
                if(service.catalog().dirty()) System.out.println("* Есть несохранённые изменения");
            }, () -> {
                if(!service.catalog().dirty()) return true;
                System.out.print("Изменения не сохранены. [s] сохранить / [n] выйти без сохранения / [c] отмена: ");
                String answer=scanner.nextLine().strip().toLowerCase(Locale.ROOT);
                if(answer.equals("c")) return false;
                if(answer.equals("n")) return true;
                if(answer.equals("s")) { try {service.save();return true;} catch(Exception ex) {System.out.println("Ошибка сохранения: "+ex.getMessage());} }
                return false;
            });
        }
    }
    private static String ask(Scanner sc,String prompt) { System.out.print(prompt); return sc.nextLine().strip(); }
    private static int number(Scanner sc,String prompt) { return Integer.parseInt(ask(sc,prompt)); }
    private static List<Integer> ids(String input) { return Arrays.stream(input.split(",")).map(String::strip).map(Integer::parseInt).toList(); }
    private static void show(List<PokemonCard> cards) {
        if(cards.isEmpty()) {System.out.println("Ничего не найдено");return;}
        for(PokemonCard c:cards) System.out.println(c.id()+" | "+c.name()+" | "+String.join(", ",c.types())+" | "+c.stats());
    }
    private static void summary(PokemonService service,String title) {
        List<PokemonCard> cards=service.catalog().members(title);
        System.out.println("Команда: "+title+"; размер: "+cards.size());
        if(cards.isEmpty()) {System.out.println("Средние не рассчитываются");return;}
        System.out.println("Типы: "+cards.stream().flatMap(c->c.types().stream()).distinct().sorted().toList());
        System.out.printf(Locale.US,"HP %.2f | Attack %.2f | Defense %.2f | Sp.Attack %.2f | Sp.Defense %.2f | Speed %.2f%n",
            cards.stream().mapToInt(c->c.stats().hp()).average().orElseThrow(),
            cards.stream().mapToInt(c->c.stats().attack()).average().orElseThrow(),
            cards.stream().mapToInt(c->c.stats().defense()).average().orElseThrow(),
            cards.stream().mapToInt(c->c.stats().specialAttack()).average().orElseThrow(),
            cards.stream().mapToInt(c->c.stats().specialDefense()).average().orElseThrow(),
            cards.stream().mapToInt(c->c.stats().speed()).average().orElseThrow());
        System.out.println("Сводка описывает характеристики, но не предсказывает исход боя.");
    }
    private static void execute(MenuAction action,PokemonService s,Scanner sc) throws Exception {
        switch(action) {
            case LOAD_ONLINE -> { s.online(ids(ask(sc,"ID через запятую (например 1,4,7): "))); System.out.println("Загрузка завершена"); }
            case IMPORT_SNAPSHOT -> {
                String line=ask(sc,"Пути к JSON через ; (например fixtures/bulbasaur.json;fixtures/charmander.json): ");
                s.importSnapshots(Arrays.stream(line.split(";")).map(String::strip).map(Path::of).toList()); System.out.println("Снимки импортированы");
            }
            case LOAD_CACHE -> {s.loadCache(ids(ask(sc,"ID кэша через запятую: ")));System.out.println("Кэш прочитан");}
            case SHOW_CATALOG -> show(s.catalog().all());
            case SEARCH -> show(s.catalog().search(ask(sc,"Часть имени: ")));
            case FILTER -> show(s.catalog().filter(ask(sc,"Тип Pokémon: ")));
            case CREATE_COLLECTION -> {s.catalog().createTeam(ask(sc,"Название команды: "));System.out.println("Команда создана");}
            case SHOW_COLLECTION -> {String title=ask(sc,"Название команды: ");show(s.catalog().members(title));}
            case ADD_ENTRY -> {String title=ask(sc,"Название команды: ");s.catalog().add(title,number(sc,"ID Pokémon: "));}
            case REMOVE_ENTRY -> {String title=ask(sc,"Название команды: ");s.catalog().remove(title,number(sc,"ID Pokémon: "));}
            case SUMMARY -> summary(s,ask(sc,"Название команды: "));
            case SAVE -> {s.save();System.out.println("Сохранено: "+s.statePath());}
            case EXPORT -> {String title=ask(sc,"Название команды: ");String file=ask(sc,"Имя экспорта (team.json): ");s.exportTeam(title,file);System.out.println("Экспорт готов");}
            case IMPORT_EXPORT -> {int count=s.importTeam(ask(sc,"Имя экспорта (team.json): "));System.out.println("Импортировано элементов: "+count);}
            case CHANGE_QUANTITY -> throw new IllegalArgumentException("Для Pokémon количество не используется");
        }
    }
}