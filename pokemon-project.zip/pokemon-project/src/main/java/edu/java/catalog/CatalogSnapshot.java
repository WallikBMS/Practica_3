package edu.java.catalog;

import java.util.List;
public record CatalogSnapshot(int schemaVersion, String variant, List<PokemonCard> catalog, List<CollectionData> collections) {
    public record CollectionData(String title, List<Item> items) {}
    public record Item(int cardId) {}
}