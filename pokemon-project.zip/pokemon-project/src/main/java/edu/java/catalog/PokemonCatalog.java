package edu.java.catalog;

import java.util.*;
public final class PokemonCatalog {
    private final Map<Integer,PokemonCard> cards = new LinkedHashMap<>();
    private final Map<String,PokemonTeam> teams = new LinkedHashMap<>();
    private boolean dirty;
    public boolean dirty() { return dirty; }
    public void clean() { dirty = false; }
    public PokemonCard get(int id) { return cards.get(id); }
    public List<PokemonCard> all() { return cards.values().stream().sorted(Comparator.comparing(PokemonCard::name)).toList(); }
    public List<PokemonCard> search(String name) { return all().stream().filter(c -> c.name().toLowerCase(Locale.ROOT).contains(name.toLowerCase(Locale.ROOT))).toList(); }
    public List<PokemonCard> filter(String type) { return all().stream().filter(c -> c.types().stream().anyMatch(t -> t.equalsIgnoreCase(type))).toList(); }
    public List<PokemonTeam> teams() { return List.copyOf(teams.values()); }
    public PokemonTeam team(String name) { return teams.get(key(name)); }
    private static String key(String s) { return s.strip().toLowerCase(Locale.ROOT); }
    public void importCards(List<PokemonCard> incoming) {
        if (incoming == null) throw new IllegalArgumentException("Нет карточек");
        Map<Integer,PokemonCard> next = new LinkedHashMap<>(cards);
        for (PokemonCard card : incoming) {
            if (card == null) throw new IllegalArgumentException("Пустая карточка");
            next.put(card.id(), card);
        }
        if (next.size() > 100) throw new IllegalArgumentException("Предел каталога: 100");
        if (!next.equals(cards)) { cards.clear(); cards.putAll(next); dirty = true; }
    }
    public void createTeam(String title) {
        PokemonTeam t = new PokemonTeam(title, List.of());
        if (teams.containsKey(key(title))) throw new IllegalArgumentException("Название уже занято");
        teams.put(key(title), t); dirty = true;
    }
    public void add(String title, int id) { update(title,id,true); }
    public void remove(String title, int id) { update(title,id,false); }
    private void update(String title, int id, boolean add) {
        PokemonTeam t = team(title);
        if (t == null) throw new IllegalArgumentException("Команда не найдена");
        if (add && !cards.containsKey(id)) throw new IllegalArgumentException("Неизвестный ID");
        List<Integer> ids = new ArrayList<>(t.items());
        if (add) { if (ids.contains(id)) throw new IllegalArgumentException("Повторный ID"); ids.add(id); }
        else { if (!ids.remove(Integer.valueOf(id))) throw new IllegalArgumentException("ID отсутствует в команде"); }
        teams.put(key(title), new PokemonTeam(t.title(), ids)); dirty = true;
    }
    public List<PokemonCard> members(String title) {
        PokemonTeam t = team(title);
        if (t == null) throw new IllegalArgumentException("Команда не найдена");
        return t.items().stream().map(cards::get).toList();
    }
    public CatalogSnapshot snapshot() {
        return new CatalogSnapshot(1,"pokemon", List.copyOf(cards.values()), teams.values().stream()
            .map(t -> new CatalogSnapshot.CollectionData(t.title(),t.items().stream().map(CatalogSnapshot.Item::new).toList())).toList());
    }
    public void restore(CatalogSnapshot s) {
        if (s == null || s.schemaVersion()!=1 || !"pokemon".equals(s.variant()) || s.catalog()==null || s.collections()==null)
            throw new IllegalArgumentException("Неверная версия, вариант или формат state.json");
        PokemonCatalog next = new PokemonCatalog();
        Set<Integer> seen = new HashSet<>();
        for (PokemonCard c : s.catalog()) { if (c == null || !seen.add(c.id())) throw new IllegalArgumentException("Дубли каталога"); next.importCards(List.of(c)); }
        for (var t : s.collections()) {
            if (t == null || t.items()==null) throw new IllegalArgumentException("Неверная команда");
            next.createTeam(t.title());
            for (var item : t.items()) { if (item == null) throw new IllegalArgumentException("Неверный элемент"); next.add(t.title(),item.cardId()); }
        }
        cards.clear(); cards.putAll(next.cards); teams.clear(); teams.putAll(next.teams); dirty = false;
    }
    public TeamExport exportTeam(String title) {
        PokemonTeam t = team(title);
        if (t == null) throw new IllegalArgumentException("Команда не найдена");
        return new TeamExport(1,"pokemon",t.title(),members(title).stream().map(TeamExport.Item::new).toList());
    }
    public int importTeam(TeamExport ex) {
        if (ex == null || ex.schemaVersion()!=1 || !"pokemon".equals(ex.variant()) || ex.items()==null)
            throw new IllegalArgumentException("Неверный экспорт");
        PokemonCatalog next = new PokemonCatalog(); next.restore(snapshot());
        next.createTeam(ex.title());
        List<PokemonCard> imported = new ArrayList<>();
        for (var item : ex.items()) { if (item == null || item.card()==null) throw new IllegalArgumentException("Неверная карточка экспорта"); imported.add(item.card()); }
        // Локальная карточка имеет приоритет.
        for (PokemonCard card : imported) if (next.get(card.id()) == null) next.importCards(List.of(card));
        for (PokemonCard card : imported) next.add(ex.title(),card.id());
        cards.clear(); cards.putAll(next.cards); teams.clear(); teams.putAll(next.teams); dirty = true;
        return imported.size();
    }
}