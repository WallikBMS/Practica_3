package edu.java.catalog;

import com.fasterxml.jackson.annotation.*;
import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)
public record PokemonResponse(Integer id, String name, List<TypeSlot> types, List<StatSlot> stats) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record TypeSlot(TypeName type) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record TypeName(String name) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record StatSlot(@JsonProperty("base_stat") Integer baseStat, StatName stat) {}
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record StatName(String name) {}
}