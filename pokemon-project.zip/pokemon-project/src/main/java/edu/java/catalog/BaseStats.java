package edu.java.catalog;

public record BaseStats(int hp, int attack, int defense, int specialAttack, int specialDefense, int speed) {
    public BaseStats {
        if (hp <= 0 || attack <= 0 || defense <= 0 || specialAttack <= 0 || specialDefense <= 0 || speed <= 0)
            throw new IllegalArgumentException("Все характеристики должны быть положительными");
    }
}